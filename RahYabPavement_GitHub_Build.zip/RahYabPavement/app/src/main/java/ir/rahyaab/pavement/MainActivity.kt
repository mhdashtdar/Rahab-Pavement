package ir.rahyaab.pavement

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.*

data class GpsPoint(val lat: Double, val lon: Double, val time: Long, val accuracy: Float)
data class RoadSegment(val id: Int, val color: String, val label: String, val points: MutableList<GpsPoint>)

class MainActivity : Activity() {
    private lateinit var fused: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private val segments = mutableListOf<RoadSegment>()
    private var active: RoadSegment? = null
    private var recording = false
    private var lastPoint: GpsPoint? = null
    private lateinit var status: TextView
    private lateinit var distance: TextView
    private lateinit var startBtn: Button
    private val colors = listOf(
        Triple("سبز", "#16A34A", "GREEN"),
        Triple("زرد", "#EAB308", "YELLOW"),
        Triple("آبی", "#2563EB", "BLUE"),
        Triple("نارنجی", "#EA580C", "ORANGE"),
        Triple("قرمز", "#DC2626", "RED")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fused = LocationServices.getFusedLocationProviderClient(this)
        buildUi()
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.locations.forEach { appendLocation(it) }
            }
        }
        ensurePermission()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        val title = TextView(this).apply {
            text = "رهیاب روسازی\nبرداشت وضعیت کیفی محور"
            textSize = 23f; gravity = Gravity.CENTER; setTextColor(0xFF172554.toInt())
        }
        root.addView(title, LinearParams(-1, 100))
        status = TextView(this).apply {
            text = "GPS: در انتظار مجوز"; textSize = 16f; gravity = Gravity.CENTER
        }
        root.addView(status, LinearParams(-1, 55))
        distance = TextView(this).apply {
            text = "طول مقطع فعال: ۰ متر"; textSize = 18f; gravity = Gravity.CENTER
        }
        root.addView(distance, LinearParams(-1, 55))
        startBtn = Button(this).apply {
            text = "شروع برداشت"
            setOnClickListener {
                if (!recording) startRecording() else stopRecording()
            }
        }
        root.addView(startBtn, LinearParams(-1, 62))
        val hint = TextView(this).apply {
            text = "برای تعیین وضعیت، رنگ را لمس کنید. همان رنگ تا انتخاب رنگ بعدی ادامه دارد."
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(0xFF475569.toInt())
        }
        root.addView(hint, LinearParams(-1, 65))
        colors.forEach { (label, hex, code) ->
            val b = Button(this).apply {
                text = label
                textSize = 20f
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor(hex)))
                isEnabled = false
                setOnClickListener { switchColor(label, code) }
            }
            root.addView(b, LinearParams(-1, 58))
            colorButtons.add(b)
        }
        val export = Button(this).apply {
            text = "پایان برداشت و خروجی KMZ + Excel"
            setOnClickListener { finishAndExport() }
        }
        root.addView(export, LinearParams(-1, 64))
        val reset = Button(this).apply {
            text = "پاک‌کردن برداشت جاری"
            setOnClickListener { resetSurvey() }
        }
        root.addView(reset, LinearParams(-1, 52))
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private val colorButtons = mutableListOf<Button>()
    private fun LinearParams(w: Int, h: Int) = LinearLayout.LayoutParams(w, h).apply { bottomMargin = 7 }

    private fun ensurePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10)
        } else status.text = "GPS آماده است"
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) status.text = "GPS آماده است"
        else status.text = "مجوز مکان داده نشد"
    }

    private fun startRecording() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ensurePermission(); return
        }
        recording = true
        startBtn.text = "توقف برداشت"
        colorButtons.forEach { it.isEnabled = true }
        status.text = "در حال ثبت مسیر GPS؛ ابتدا یک رنگ انتخاب کنید"
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
            .setMinUpdateDistanceMeters(2f).build()
        fused.requestLocationUpdates(request, locationCallback, mainLooper)
    }
    private fun stopRecording() {
        recording = false
        fused.removeLocationUpdates(locationCallback)
        startBtn.text = "ادامه برداشت"
        colorButtons.forEach { it.isEnabled = false }
        status.text = "برداشت متوقف شد"
    }
    private fun switchColor(label: String, code: String) {
        if (!recording) return
        val current = lastPoint
        if (active != null && active!!.points.isEmpty() && current != null) active!!.points.add(current)
        val seg = RoadSegment(segments.size + 1, code, label, mutableListOf())
        if (current != null) seg.points.add(current)
        segments.add(seg); active = seg
        status.text = "وضعیت فعال: $label"
        updateDistance()
    }
    private fun appendLocation(location: Location) {
        if (!recording) return
        val p = GpsPoint(location.latitude, location.longitude, location.time, location.accuracy)
        lastPoint = p
        active?.let { seg ->
            val prev = seg.points.lastOrNull()
            if (prev == null || distanceMeters(prev, p) >= 1.0) seg.points.add(p)
        }
        status.text = "GPS فعال | دقت تقریبی ${location.accuracy.toInt()} متر | مقاطع ${segments.size}"
        updateDistance()
    }
    private fun updateDistance() {
        val len = active?.let { length(it.points) } ?: 0.0
        distance.text = "طول مقطع فعال: ${len.roundToInt()} متر"
    }
    private fun distanceMeters(a: GpsPoint, b: GpsPoint): Double {
        val out = FloatArray(1)
        Location.distanceBetween(a.lat, a.lon, b.lat, b.lon, out)
        return out[0].toDouble()
    }
    private fun length(points: List<GpsPoint>): Double = points.zipWithNext().sumOf { distanceMeters(it.first, it.second) }

    private fun finishAndExport() {
        if (recording) stopRecording()
        val usable = segments.filter { it.points.size >= 2 }
        if (usable.isEmpty()) { toast("برای خروجی، حداقل یک مقطع با دو نقطه GPS لازم است"); return }
        try {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
            val kmz = makeKmz(usable)
            val xlsx = makeExcel(usable)
            saveDownload("RahYab_$stamp.kmz", "application/vnd.google-earth.kmz", kmz)
            saveDownload("RahYab_$stamp.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", xlsx)
            toast("دو فایل KMZ و Excel در پوشه Downloads ذخیره شد")
        } catch (e: Exception) { toast("خطا در ساخت خروجی: ${e.message}") }
    }
    private fun makeKmz(data: List<RoadSegment>): ByteArray {
        val kml = buildString {
            append("""<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>برداشت وضعیت روسازی</name>""")
            val kmlColors = mapOf("GREEN" to "ff00a000", "YELLOW" to "ff00ffff", "BLUE" to "ffff8000", "ORANGE" to "ff0080ff", "RED" to "ff0000ff")
            data.forEach { s ->
                val len = length(s.points)
                append("<Style id=\"s${s.id}\"><LineStyle><color>${kmlColors[s.color]}</color><width>6</width></LineStyle></Style>")
                append("<Placemark><name>مقطع ${s.id} - ${s.label} - ${len.roundToInt()} متر</name><styleUrl>#s${s.id}</styleUrl><description><![CDATA[وضعیت: ${s.label}<br/>طول: ${"%.1f".format(Locale.US,len)} متر<br/>تعداد نقاط: ${s.points.size}]]></description><LineString><tessellate>1</tessellate><coordinates>")
                s.points.forEach { append("${it.lon},${it.lat},0 ") }
                append("</coordinates></LineString></Placemark>")
            }
            append("</Document></kml>")
        }
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip -> zip.putNextEntry(ZipEntry("doc.kml")); zip.write(kml.toByteArray(Charsets.UTF_8)); zip.closeEntry() }
        return out.toByteArray()
    }
    private fun makeExcel(data: List<RoadSegment>): ByteArray {
        val headers = listOf("شماره مقطع","وضعیت","کد رنگ","طول (متر)","عرض جغرافیایی ابتدا","طول جغرافیایی ابتدا","عرض جغرافیایی انتها","طول جغرافیایی انتها","تعداد نقاط")
        val rows = mutableListOf<List<String>>()
        rows.add(headers)
        data.forEach { s ->
            val first=s.points.first(); val last=s.points.last()
            rows.add(listOf(s.id.toString(),s.label,s.color,"%.1f".format(Locale.US,length(s.points)),
                first.lat.toString(),first.lon.toString(),last.lat.toString(),last.lon.toString(),s.points.size.toString()))
        }
        fun colName(n0:Int):String {
            var n=n0+1; var out=""
            while(n>0){ val rem=(n-1)%26; out=('A'.code+rem).toChar()+out; n=(n-1)/26 }
            return out
        }
        val sheet = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
            rows.forEachIndexed { ri,row ->
                append("<row r=\"${ri+1}\">")
                row.forEachIndexed { ci,value ->
                    val ref="${colName(ci)}${ri+1}"
                    val safe=value.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
                    append("<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">$safe</t></is></c>")
                }
                append("</row>")
            }
            append("</sheetData></worksheet>")
        }
        val entries = linkedMapOf(
            "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""",
            "_rels/.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""",
            "xl/workbook.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="مقاطع روسازی" sheetId="1" r:id="rId1"/></sheets></workbook>""",
            "xl/_rels/workbook.xml.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""",
            "xl/worksheets/sheet1.xml" to sheet
        )
        val out=ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            entries.forEach { (name,content) ->
                zip.putNextEntry(ZipEntry(name)); zip.write(content.toByteArray(Charsets.UTF_8)); zip.closeEntry()
            }
        }
        return out.toByteArray()
    }
    private fun saveDownload(name: String, mime: String, bytes: ByteArray) {
        val values=ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME,name); put(MediaStore.Downloads.MIME_TYPE,mime); put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS) }
        val uri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values) ?: error("ذخیره فایل ناموفق بود")
        contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: error("فایل باز نشد")
    }
    private fun resetSurvey() {
        if (recording) stopRecording()
        segments.clear(); active=null; lastPoint=null
        status.text="برداشت پاک شد"; updateDistance()
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    override fun onDestroy() { fused.removeLocationUpdates(locationCallback); super.onDestroy() }
}
